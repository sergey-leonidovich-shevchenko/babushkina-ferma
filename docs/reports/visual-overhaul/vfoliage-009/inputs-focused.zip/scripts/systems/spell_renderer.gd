class_name SpellRenderer
extends RefCounted

const Style := preload("res://scripts/presentation/moon_theme.gd")

const CYCLE_BUTTON:=Rect2(1018,444,54,54)
const CAST_BUTTON:=Rect2(1078,444,54,54)

## Возвращает адаптивную область сенсорного переключения выбранного заклинания.
static func cycle_button_rect(game: Node) -> Rect2:
	var cast: Rect2 = cast_button_rect(game); var size: Vector2 = game.UiScaleSystem.touch_rect(game, CYCLE_BUTTON).size
	return Rect2(Vector2(cast.position.x - 6.0 - size.x, CYCLE_BUTTON.get_center().y - size.y * 0.5), size)

## Возвращает адаптивную область сенсорного применения выбранного заклинания.
static func cast_button_rect(game: Node) -> Rect2:
	var size: Vector2 = game.UiScaleSystem.touch_rect(game, CAST_BUTTON).size
	return Rect2(Vector2(1152.0 - 20.0 - size.x, CAST_BUTTON.get_center().y - size.y * 0.5), size)

## Отрисовывает короткие световые круги лечения, снаряда и ледяной волны в координатах мира.
static func draw_world(game: Node) -> void:
	for effect in game.SpellSystem.state(game).effects:
		var progress:=1.0-clampf(float(effect.timer)/0.45,0.0,1.0); var color:=Color("75b8ff") if effect.kind=="arcane_bolt" else (Color("8cff9a") if effect.kind=="healing_light" else Color("b8efff")); color.a=1.0-progress; game.draw_circle(Vector2(effect.position),24.0+progress*95.0,color,false,4.0)

## Отрисовывает выбранное заклинание, стоимость, перезарядку и две сенсорные кнопки.
static func draw_ui(game: Node) -> void:
	if not game.touch_controls_visible: return
	if game.inventory_open or game.shop_open or game.quest_log_open or game.world_map_open or game.skill_menu_open or game.crafting_open or game.storage_open or game.forge_open or game.AdventurePolishSystem.has_modal(game) or game.FirstChapterSystem.modal_active(game) or game.state.fishing.phase != game.FishingSystem.PHASE_IDLE: return
	var spell:Dictionary=game.SpellSystem.selected(game); var cooldown:float=game.SpellSystem.selected_cooldown(game); var rect:=Rect2(910,592,222,42)
	game.InterfaceRenderer.HudRenderer.draw_quiet_panel(game,rect)
	game.draw_ui_string(game.UI_FONT,rect.position+Vector2(12,17),"%s %s"%[spell.icon,game.SpellSystem.word(game,String(spell.id))],HORIZONTAL_ALIGNMENT_LEFT,198,11,Style.TEXT); game.draw_ui_string(game.UI_FONT,rect.position+Vector2(12,33),"C • %d MP%s"%[spell.cost," • %.1f"%cooldown if cooldown>0.0 else ""],HORIZONTAL_ALIGNMENT_LEFT,198,10,Style.MUTED)
	if game.touch_controls_visible:
		for data in [[cycle_button_rect(game),"↻"],[cast_button_rect(game),String(spell.icon)]]: Style.panel(game,data[0]); game.draw_ui_string(game.UI_FONT,data[0].position+Vector2(5,data[0].size.y*0.65),data[1],HORIZONTAL_ALIGNMENT_CENTER,data[0].size.x-10,23,Style.TEXT)
