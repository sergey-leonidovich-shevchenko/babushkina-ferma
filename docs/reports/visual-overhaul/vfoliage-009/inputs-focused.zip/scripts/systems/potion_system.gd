extends RefCounted

const POTIONS := {
	"healing_potion": {"message":"+60 HP"},
	"mana_potion": {"message":"+30 маны"},
	"energy_potion": {"message":"+8 энергии"},
	"invisibility_potion": {"timer":"invisibility_timer", "duration":18.0, "message":"невидимость на 18 секунд"},
	"strength_potion": {"timer":"strength_timer", "duration":30.0, "message":"сила на 30 секунд"},
	"regeneration_potion": {"timer":"regeneration_timer", "duration":20.0, "message":"регенерация на 20 секунд"},
	"speed_potion": {"timer":"speed_timer", "duration":25.0, "message":"скорость на 25 секунд"},
	"defense_potion": {"timer":"defense_timer", "duration":30.0, "message":"защита на 30 секунд"},
}


## Проверяет, относится ли предмет к зарегистрированной линейке зелий.
static func is_potion(kind: String) -> bool:
	return POTIONS.has(kind) or preload("res://scripts/systems/alchemy_product_data.gd").POTIONS.has(kind)


## Употребляет еду или зелье, применяет эффект и обновляет шаг обучения.
static func consume(game: Node, kind: String) -> bool:
	if kind == "qa_teleport_stone": return preload("res://scripts/systems/qa_teleport_system.gd").open(game)
	if preload("res://scripts/systems/garden_crafting_system.gd").FERTILIZERS.has(kind): return preload("res://scripts/systems/garden_crafting_system.gd").apply(game,kind)
	if not game.InventorySystem.can_use(kind):
		game.message = game.LocaleSystem.text("cannot_use")
		return false
	if not game.change_inventory_count(kind, -1):
		game.message = "Предмет закончился"
		return false
	if preload("res://scripts/systems/alchemy_product_data.gd").POTIONS.has(kind):
		preload("res://scripts/systems/alchemy_system.gd").apply_potion(game,kind)
	elif is_potion(kind):
		_apply_potion(game, kind)
		game.notify_tutorial("potion")
		if kind == "invisibility_potion": game.notify_tutorial("invisibility")
	else:
		_apply_food(game, kind)
	game.notify_tutorial("eat")
	return true


## Применяет мгновенный или временный эффект выбранного зелья.
static func _apply_potion(game: Node, kind: String) -> void:
	var data: Dictionary = POTIONS[kind]
	match kind:
		"healing_potion": game.heal_player(60)
		"mana_potion": game.player_mana = mini(game.player_mana + 30, game.player_max_mana)
		"energy_potion": game.energy = mini(game.energy + 8, game.SkillSystem.max_stamina(game))
		_:
			game.set(data.timer, maxf(float(game.get(data.timer)), float(data.duration) * game.EstateSystem.potion_multiplier(game)))
			if kind == "regeneration_potion": game.regeneration_tick_timer = 0.0
	game.message = "%s: %s" % [game.inventory_item_name(kind), data.message]


## Применяет существующие пищевые эффекты через единый конвейер расходников.
static func _apply_food(game: Node, kind: String) -> void:
	preload("res://scripts/systems/food_system.gd").apply(game,kind)


## Обновляет длительность бафов и периодическое восстановление здоровья.
static func update_effects(game: Node, delta: float) -> void:
	preload("res://scripts/systems/alchemy_system.gd").update(game,delta)
	for timer in ["strength_timer", "speed_timer", "invisibility_timer", "defense_timer"]:
		game.set(timer, maxf(float(game.get(timer)) - delta, 0.0))
	if game.regeneration_timer <= 0.0: return
	var elapsed:=minf(maxf(delta,0.0),float(game.regeneration_timer))
	game.regeneration_timer = maxf(game.regeneration_timer - elapsed, 0.0)
	game.regeneration_tick_timer += elapsed
	while game.regeneration_tick_timer >= 1.0:
		game.regeneration_tick_timer -= 1.0
		game.heal_player(5)


## Снимает невидимость после агрессивного действия героя.
static func break_invisibility(game: Node) -> bool:
	if game.invisibility_timer <= 0.0:
		return false
	game.invisibility_timer = 0.0
	game.message = "Невидимость рассеялась после атаки"
	return true
