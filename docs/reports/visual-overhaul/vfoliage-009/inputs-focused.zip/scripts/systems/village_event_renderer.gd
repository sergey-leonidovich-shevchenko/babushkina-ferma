extends RefCounted
const Trade:=preload("res://scripts/presentation/village_trade_visual.gd")


## Рисует объект активного события площади и его короткое состояние.
static func draw(game: Node2D,foreground:bool=false) -> void:
	if game.current_location != "overworld": return
	var event := String(game.state.world.estate.event)
	if not game.VillageEventSystem.POSITIONS.has(event): return
	if event == "traveler" and game.game_minutes < 18.0 * 60.0: return
	if foreground:
		if event=="market":Trade.draw_market(game,true)
		return
	var position: Vector2 = game.VillageEventSystem.POSITIONS[event]
	var column: int = int({"market":0,"festival":1,"traveler":2,"raid":3}[event])
	if event=="market":Trade.draw_market(game)
	else:game.WorldPolishRenderer.draw_cell(game,column,1,Rect2(position-Vector2(72,72),Vector2(144,144)))
	var label: String = String({"market":"ЯРМАРКА","festival":"ПРАЗДНИК УРОЖАЯ","traveler":"НОЧНОЙ ТОРГОВЕЦ","raid":"БАРРИКАДА"}[event])
	game.draw_ui_string(game.UI_FONT,position+Vector2(-105,80),label,HORIZONTAL_ALIGNMENT_CENTER,210,14,Color("fff0bd"))
