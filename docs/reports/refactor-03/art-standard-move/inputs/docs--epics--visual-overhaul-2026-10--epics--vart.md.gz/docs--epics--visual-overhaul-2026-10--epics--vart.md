# VART · Художественный стандарт живописной игры

[Все эпики](../TASKS.md) · [Аудит](../AUDIT.md)

<a id="vart-001"></a>

## VART-001 — Выбрать степень живописности

Статус: `done` · P0 · этап `foundation` · `engineering`

Показать два модульных варианта одного участка с одинаковой камерой; выбор оформлен до изменения runtime

Ветка: `codex/vart-001-visual-task`.

Зависимости: VBASE-004.

Исходники:

- [docs/ART_GUIDE.md](../../../../docs/ART_GUIDE.md)
- [docs/SPRITE_STANDARD.md](../../../../docs/SPRITE_STANDARD.md)
- [assets/game/world_sprite_manifest.json](../../../../assets/game/world_sprite_manifest.json)

Результаты: `docs/reports/visual-overhaul/vart-001/`.

Критерии:

- Показать два модульных варианта одного участка с одинаковой камерой; выбор оформлен до изменения runtime
- Сравнение выполнено при одинаковой камере; подтверждение связано с commit и конфигурацией, не только с зелёным автотестом.

Проверка:

- Показать лист вариантов в игровом масштабе на светлом/тёмном фоне; сохранить выбор пользователя, rejected варианты не импортировать.
- Перед commit/push выполнить TESTING.md; для runtime дополнительно нативный кадр/видео и профильные тесты.

Риск: Несогласованные масштаб, порядок слоёв или стоимость могут ухудшить соседние объекты; оценивать в игровой сцене.

Откат: Отдельный commit; предыдущий ресурс/профиль сохранить до приёмки, откатить ссылку или выключить флаг эффекта без изменения сохранений.

Оценка: [1, 3] рабочих дней, уверенность low. Рабочая гипотеза на одну карточку; уточнить по пилоту. Не календарное обещание.

Доказательства: docs/reports/visual-overhaul/vart-001/README.md, docs/reports/visual-overhaul/vart-001/index.html, docs/reports/visual-overhaul/vart-001/review.json, docs/reports/visual-overhaul/vart-001/scene-a.png, docs/reports/visual-overhaul/vart-001/scene-b.png, docs/reports/visual-overhaul/vart-001/modules-a.png, docs/reports/visual-overhaul/vart-001/modules-b.png.

<a id="vart-002"></a>

## VART-002 — Согласовать размер героя в кадре

Статус: `done` · P0 · этап `foundation` · `engineering`

Сравнить текущий размер с двумя полями обзора; не менять коллизию героя ради уменьшения рисунка

Ветка: `codex/vart-002-visual-task`.

Зависимости: VART-001, VCAMERA-001.

Исходники:

- [docs/ART_GUIDE.md](../../../../docs/ART_GUIDE.md)
- [docs/SPRITE_STANDARD.md](../../../../docs/SPRITE_STANDARD.md)
- [assets/game/world_sprite_manifest.json](../../../../assets/game/world_sprite_manifest.json)

Результаты: `docs/reports/visual-overhaul/vart-002/`.

Критерии:

- Сравнить текущий размер с двумя полями обзора; не менять коллизию героя ради уменьшения рисунка
- Сравнение выполнено при одинаковой камере; подтверждение связано с commit и конфигурацией, не только с зелёным автотестом.

Проверка:

- Показать лист вариантов в игровом масштабе на светлом/тёмном фоне; сохранить выбор пользователя, rejected варианты не импортировать.
- Перед commit/push выполнить TESTING.md; для runtime дополнительно нативный кадр/видео и профильные тесты.

Риск: Несогласованные масштаб, порядок слоёв или стоимость могут ухудшить соседние объекты; оценивать в игровой сцене.

Откат: Отдельный commit; предыдущий ресурс/профиль сохранить до приёмки, откатить ссылку или выключить флаг эффекта без изменения сохранений.

Оценка: [1, 3] рабочих дней, уверенность low. Рабочая гипотеза на одну карточку; уточнить по пилоту. Не календарное обещание.

Доказательства: docs/reports/visual-overhaul/vart-002/README.md, docs/reports/visual-overhaul/vart-002/index.html, docs/reports/visual-overhaul/vart-002/review.json, docs/reports/visual-overhaul/vart-002/scale-profile.json, docs/reports/visual-overhaul/vart-002/native/source.json, docs/reports/visual-overhaul/vart-002/native/capture.json.

<a id="vart-003"></a>

## VART-003 — Задать палитру материалов

Статус: `done` · P0 · этап `foundation` · `engineering`

Трава, дерево, камень, земля, вода и металл имеют дневные и вечерние образцы; цвет не единственный признак ресурса

Ветка: `codex/vart-003-visual-task`.

Зависимости: VART-001.

Исходники:

- [docs/ART_GUIDE.md](../../../../docs/ART_GUIDE.md)
- [docs/SPRITE_STANDARD.md](../../../../docs/SPRITE_STANDARD.md)
- [assets/game/world_sprite_manifest.json](../../../../assets/game/world_sprite_manifest.json)

Результаты: `docs/reports/visual-overhaul/vart-003/`.

Критерии:

- Трава, дерево, камень, земля, вода и металл имеют дневные и вечерние образцы; цвет не единственный признак ресурса
- Сравнение выполнено при одинаковой камере; подтверждение связано с commit и конфигурацией, не только с зелёным автотестом.

Проверка:

- Показать лист вариантов в игровом масштабе на светлом/тёмном фоне; сохранить выбор пользователя, rejected варианты не импортировать.
- Перед commit/push выполнить TESTING.md; для runtime дополнительно нативный кадр/видео и профильные тесты.

Риск: Несогласованные масштаб, порядок слоёв или стоимость могут ухудшить соседние объекты; оценивать в игровой сцене.

Откат: Отдельный commit; предыдущий ресурс/профиль сохранить до приёмки, откатить ссылку или выключить флаг эффекта без изменения сохранений.

Оценка: [1, 3] рабочих дней, уверенность low. Рабочая гипотеза на одну карточку; уточнить по пилоту. Не календарное обещание.

Доказательства: docs/reports/visual-overhaul/vart-003/README.md, docs/reports/visual-overhaul/vart-003/index.html, docs/reports/visual-overhaul/vart-003/palette.json, docs/reports/visual-overhaul/vart-003/source.json, docs/reports/visual-overhaul/vart-003/measurements.json, docs/reports/visual-overhaul/vart-003/browser-check.json, docs/reports/visual-overhaul/vart-003/browser-artifacts.json.

<a id="vart-004"></a>

## VART-004 — Закрепить перспективу предметов

Статус: `done` · P0 · этап `foundation` · `engineering`

Лево, право и вниз; опора на сетке 24; показаны запрещённые диагональные и задние виды без подключения в игру

Ветка: `codex/vart-004-visual-task`.

Зависимости: VART-002.

Единый владелец пересечения: **UX-05**. Эта карточка уточняет работу владельца, не закрывает его автоматически.

Исходники:

- [docs/ART_GUIDE.md](../../../../docs/ART_GUIDE.md)
- [docs/SPRITE_STANDARD.md](../../../../docs/SPRITE_STANDARD.md)
- [assets/game/world_sprite_manifest.json](../../../../assets/game/world_sprite_manifest.json)

Результаты: `docs/reports/visual-overhaul/vart-004/`.

Критерии:

- Лево, право и вниз; опора на сетке 24; показаны запрещённые диагональные и задние виды без подключения в игру
- Сравнение выполнено при одинаковой камере; подтверждение связано с commit и конфигурацией, не только с зелёным автотестом.

Проверка:

- Показать лист вариантов в игровом масштабе на светлом/тёмном фоне; сохранить выбор пользователя, rejected варианты не импортировать.
- Перед commit/push выполнить TESTING.md; для runtime дополнительно нативный кадр/видео и профильные тесты.

Риск: Несогласованные масштаб, порядок слоёв или стоимость могут ухудшить соседние объекты; оценивать в игровой сцене.

Откат: Отдельный commit; предыдущий ресурс/профиль сохранить до приёмки, откатить ссылку или выключить флаг эффекта без изменения сохранений.

Оценка: [1, 3] рабочих дней, уверенность low. Рабочая гипотеза на одну карточку; уточнить по пилоту. Не календарное обещание.

Доказательства: docs/reports/visual-overhaul/vart-004/README.md, docs/reports/visual-overhaul/vart-004/index.html, docs/reports/visual-overhaul/vart-004/standard.json, docs/reports/visual-overhaul/vart-004/runtime-export.json, docs/reports/visual-overhaul/vart-004/source.json, docs/reports/visual-overhaul/vart-004/export-check.json, docs/reports/visual-overhaul/vart-004/browser-check.json, docs/reports/visual-overhaul/vart-004/browser-artifacts.json.

<a id="vart-005"></a>

## VART-005 — Согласовать мягкость контура

Статус: `done` · P0 · этап `foundation` · `engineering`

Проверить мастера на светлом, тёмном и травяном фоне при реальном масштабе; нет белой каймы и размытого силуэта

Ветка: `codex/vart-005-visual-task`.

Зависимости: VART-001.

Исходники:

- [docs/ART_GUIDE.md](../../../../docs/ART_GUIDE.md)
- [docs/SPRITE_STANDARD.md](../../../../docs/SPRITE_STANDARD.md)
- [assets/game/world_sprite_manifest.json](../../../../assets/game/world_sprite_manifest.json)

Результаты: `docs/reports/visual-overhaul/vart-005/`.

Критерии:

- Проверить мастера на светлом, тёмном и травяном фоне при реальном масштабе; нет белой каймы и размытого силуэта
- Сравнение выполнено при одинаковой камере; подтверждение связано с commit и конфигурацией, не только с зелёным автотестом.

Проверка:

- Показать лист вариантов в игровом масштабе на светлом/тёмном фоне; сохранить выбор пользователя, rejected варианты не импортировать.
- Перед commit/push выполнить TESTING.md; для runtime дополнительно нативный кадр/видео и профильные тесты.

Риск: Несогласованные масштаб, порядок слоёв или стоимость могут ухудшить соседние объекты; оценивать в игровой сцене.

Откат: Отдельный commit; предыдущий ресурс/профиль сохранить до приёмки, откатить ссылку или выключить флаг эффекта без изменения сохранений.

Оценка: [1, 3] рабочих дней, уверенность low. Рабочая гипотеза на одну карточку; уточнить по пилоту. Не календарное обещание.

Доказательства: docs/reports/visual-overhaul/vart-005/README.md, docs/reports/visual-overhaul/vart-005/edge-profile.json, docs/reports/visual-overhaul/vart-005/source.json, docs/reports/visual-overhaul/vart-005/browser-check.json, docs/reports/visual-overhaul/vart-005/browser-artifacts.json, tools/visual_edges.py, tools/test_visual_edges.py, 17 октября 2026: прямой ответ пользователя «A — естественный край (рекомендую)»; принят стандарт без общей дополнительной обводки. Шесть модулей одного RGBA-мастера, A/B × четыре фона, неизменные область 1152×648, поле 960×540 и проекция 1.2. Это браузерная художественная приёмка; runtime и assets/game не менялись..

<a id="vart-006"></a>

## VART-006 — Задать плотность деталей

Статус: `done` · P0 · этап `foundation` · `engineering`

Один лист сравнивает героя, дверь, дерево, стол и траву; мелкие детали не соревнуются с интерактивными объектами

Ветка: `codex/vart-006-visual-task`.

Зависимости: VART-001.

Исходники:

- [docs/ART_GUIDE.md](../../../../docs/ART_GUIDE.md)
- [docs/SPRITE_STANDARD.md](../../../../docs/SPRITE_STANDARD.md)
- [assets/game/world_sprite_manifest.json](../../../../assets/game/world_sprite_manifest.json)
- [docs/reports/visual-overhaul/vart-004/README.md](../../../../docs/reports/visual-overhaul/vart-004/README.md)
- [docs/reports/visual-overhaul/vart-005/README.md](../../../../docs/reports/visual-overhaul/vart-005/README.md)

Результаты: `docs/reports/visual-overhaul/vart-006/`.

Критерии:

- Один лист сравнивает героя, дверь, дерево, стол и траву; мелкие детали не соревнуются с интерактивными объектами
- Сравнение выполнено при одинаковой камере; подтверждение связано с commit и конфигурацией, не только с зелёным автотестом.

Проверка:

- Показать лист вариантов в игровом масштабе на светлом/тёмном фоне; сохранить выбор пользователя, rejected варианты не импортировать.
- Перед commit/push выполнить TESTING.md; для runtime дополнительно нативный кадр/видео и профильные тесты.

Риск: Несогласованные масштаб, порядок слоёв или стоимость могут ухудшить соседние объекты; оценивать в игровой сцене.

Откат: Отдельный commit; предыдущий ресурс/профиль сохранить до приёмки, откатить ссылку или выключить флаг эффекта без изменения сохранений.

Оценка: [1, 3] рабочих дней, уверенность low. Рабочая гипотеза на одну карточку; уточнить по пилоту. Не календарное обещание.

Доказательства: docs/reports/visual-overhaul/vart-006/README.md, docs/reports/visual-overhaul/vart-006/density-profile.json, docs/reports/visual-overhaul/vart-006/source.json, docs/reports/visual-overhaul/vart-006/browser-check.json, docs/reports/visual-overhaul/vart-006/native/capture.json, docs/reports/visual-overhaul/vart-006/native/pairs.png, tools/visual_density.py, tools/test_visual_density.py, tools/visual_density_capture.gd, 17 октября 2026: пользователь выбрал «B — ремесленная фактура». Сохранены мягкий стиль VART-001 A, палитра A и край A. Пять образцов с общим героем, одинаковыми source rect/опорами и проекцией 1.2; 12 DOM-состояний, шесть настоящих GPU Image 1152×648 и парный лист 1152×960 с равными повторами. Этюды не импортированы в игру; FPS и игровые локации не принимаются..

<a id="vart-007"></a>

## VART-007 — Утвердить направление света

Статус: `done` · P0 · этап `foundation` · `engineering`

Показать раздельно локальную форму, контакт и падающую тень; в рисунке нет второй конфликтующей солнечной тени

Ветка: `codex/vart-007-visual-task`.

Зависимости: VART-001.

Исходники:

- [docs/ART_GUIDE.md](../../../../docs/ART_GUIDE.md)
- [docs/SPRITE_STANDARD.md](../../../../docs/SPRITE_STANDARD.md)
- [assets/game/world_sprite_manifest.json](../../../../assets/game/world_sprite_manifest.json)

Результаты: `docs/reports/visual-overhaul/vart-007/`.

Критерии:

- Показать раздельно локальную форму, контакт и падающую тень; в рисунке нет второй конфликтующей солнечной тени
- Сравнение выполнено при одинаковой камере; подтверждение связано с commit и конфигурацией, не только с зелёным автотестом.

Проверка:

- Показать лист вариантов в игровом масштабе на светлом/тёмном фоне; сохранить выбор пользователя, rejected варианты не импортировать.
- Перед commit/push выполнить TESTING.md; для runtime дополнительно нативный кадр/видео и профильные тесты.

Риск: Несогласованные масштаб, порядок слоёв или стоимость могут ухудшить соседние объекты; оценивать в игровой сцене.

Откат: Отдельный commit; предыдущий ресурс/профиль сохранить до приёмки, откатить ссылку или выключить флаг эффекта без изменения сохранений.

Оценка: [1, 3] рабочих дней, уверенность low. Рабочая гипотеза на одну карточку; уточнить по пилоту. Не календарное обещание.

Доказательства: docs/reports/visual-overhaul/vart-007/README.md, docs/reports/visual-overhaul/vart-007/light-profile.json, docs/reports/visual-overhaul/vart-007/native/capture.json, tools/visual_light.py, tools/test_visual_light.py, tools/visual_light_capture.gd.

<a id="vart-008"></a>

## VART-008 — Нарисовать набор эталонного участка

Статус: `done` · P0 · этап `foundation` · `engineering`

6–10 пучков, два куста, дерево, земля, края дороги, берег, мост и фасад представлены отдельными мастерами

Ветка: `codex/vart-008-visual-task`.

Зависимости: VART-003, VART-004, VART-005, VART-006, VART-007.

Исходники:

- [docs/ART_GUIDE.md](../../../../docs/ART_GUIDE.md)
- [docs/SPRITE_STANDARD.md](../../../../docs/SPRITE_STANDARD.md)
- [assets/game/world_sprite_manifest.json](../../../../assets/game/world_sprite_manifest.json)
- [docs/reports/visual-overhaul/vart-005/README.md](../../../../docs/reports/visual-overhaul/vart-005/README.md)
- [docs/reports/visual-overhaul/vart-006/README.md](../../../../docs/reports/visual-overhaul/vart-006/README.md)

Результаты: `docs/reports/visual-overhaul/vart-008/`.

Критерии:

- 6–10 пучков, два куста, дерево, земля, края дороги, берег, мост и фасад представлены отдельными мастерами
- Сравнение выполнено при одинаковой камере; подтверждение связано с commit и конфигурацией, не только с зелёным автотестом.

Проверка:

- Показать лист вариантов в игровом масштабе на светлом/тёмном фоне; сохранить выбор пользователя, rejected варианты не импортировать.
- Перед commit/push выполнить TESTING.md; для runtime дополнительно нативный кадр/видео и профильные тесты.

Риск: Несогласованные масштаб, порядок слоёв или стоимость могут ухудшить соседние объекты; оценивать в игровой сцене.

Откат: Отдельный commit; предыдущий ресурс/профиль сохранить до приёмки, откатить ссылку или выключить флаг эффекта без изменения сохранений.

Оценка: [1, 3] рабочих дней, уверенность low. Рабочая гипотеза на одну карточку; уточнить по пилоту. Не календарное обещание.

Доказательства: docs/reports/visual-overhaul/vart-008/README.md, docs/reports/visual-overhaul/vart-008/modules.json, docs/reports/visual-overhaul/vart-008/measurements.json, docs/reports/visual-overhaul/vart-008/source.json, docs/reports/visual-overhaul/vart-008/native/capture.json, docs/reports/visual-overhaul/vart-008/browser.json, tools/visual_modules.py, tools/test_visual_modules.py, tools/visual_modules_capture.gd.

<a id="vart-009"></a>

## VART-009 — Подготовить таблицу сохранить или заменить

Статус: `done` · P0 · этап `foundation` · `engineering`

Каждое из 29 семейств манифеста получает решение reuse, adapt или redraw с причиной; количество задач не означает обязательную перерисовку всего

Ветка: `codex/vart-009-visual-task`.

Зависимости: VART-001.

Исходники:

- [docs/ART_GUIDE.md](../../../../docs/ART_GUIDE.md)
- [docs/SPRITE_STANDARD.md](../../../../docs/SPRITE_STANDARD.md)
- [assets/game/world_sprite_manifest.json](../../../../assets/game/world_sprite_manifest.json)

Результаты: `docs/reports/visual-overhaul/vart-009/`.

Критерии:

- Каждое из 29 семейств манифеста получает решение reuse, adapt или redraw с причиной; количество задач не означает обязательную перерисовку всего
- Сравнение выполнено при одинаковой камере; подтверждение связано с commit и конфигурацией, не только с зелёным автотестом.

Проверка:

- Показать лист вариантов в игровом масштабе на светлом/тёмном фоне; сохранить выбор пользователя, rejected варианты не импортировать.
- Перед commit/push выполнить TESTING.md; для runtime дополнительно нативный кадр/видео и профильные тесты.

Риск: Несогласованные масштаб, порядок слоёв или стоимость могут ухудшить соседние объекты; оценивать в игровой сцене.

Откат: Отдельный commit; предыдущий ресурс/профиль сохранить до приёмки, откатить ссылку или выключить флаг эффекта без изменения сохранений.

Оценка: [1, 3] рабочих дней, уверенность low. Рабочая гипотеза на одну карточку; уточнить по пилоту. Не календарное обещание.

Доказательства: docs/reports/visual-overhaul/vart-009/README.md, docs/reports/visual-overhaul/vart-009/decisions.json, docs/reports/visual-overhaul/vart-009/inventory.json, docs/reports/visual-overhaul/vart-009/native/capture.json, docs/reports/visual-overhaul/vart-009/browser.json, tools/visual_reuse.py, tools/test_visual_reuse.py, tools/visual_reuse_capture.gd, tools/visual_reuse_sources.gd.

<a id="vart-010"></a>

## VART-010 — Утвердить предметный эталон иконок

Статус: `done` · P0 · этап `foundation` · `engineering`

По одному примеру еды, руды, травы, колбы, инструмента и одежды проверено в 64 и 160 пикселях до массовой партии

Ветка: `codex/vart-010-visual-task`.

Зависимости: VART-003, VART-005.

Исходники:

- [docs/ART_GUIDE.md](../../../../docs/ART_GUIDE.md)
- [docs/SPRITE_STANDARD.md](../../../../docs/SPRITE_STANDARD.md)
- [assets/game/world_sprite_manifest.json](../../../../assets/game/world_sprite_manifest.json)

Результаты: `docs/reports/visual-overhaul/vart-010/`.

Критерии:

- По одному примеру еды, руды, травы, колбы, инструмента и одежды проверено в 64 и 160 пикселях до массовой партии
- Сравнение выполнено при одинаковой камере; подтверждение связано с commit и конфигурацией, не только с зелёным автотестом.

Проверка:

- Показать лист вариантов в игровом масштабе на светлом/тёмном фоне; сохранить выбор пользователя, rejected варианты не импортировать.
- Перед commit/push выполнить TESTING.md; для runtime дополнительно нативный кадр/видео и профильные тесты.

Риск: Несогласованные масштаб, порядок слоёв или стоимость могут ухудшить соседние объекты; оценивать в игровой сцене.

Откат: Отдельный commit; предыдущий ресурс/профиль сохранить до приёмки, откатить ссылку или выключить флаг эффекта без изменения сохранений.

Оценка: [1, 3] рабочих дней, уверенность low. Рабочая гипотеза на одну карточку; уточнить по пилоту. Не календарное обещание.

Доказательства: docs/reports/visual-overhaul/vart-010/README.md, docs/reports/visual-overhaul/vart-010/icons.json, docs/reports/visual-overhaul/vart-010/review.json, docs/reports/visual-overhaul/vart-010/source.json, docs/reports/visual-overhaul/vart-010/native/capture.json, docs/reports/visual-overhaul/vart-010/browser.json, tools/visual_icons.py, tools/test_visual_icons.py, tools/visual_icons_capture.gd.
