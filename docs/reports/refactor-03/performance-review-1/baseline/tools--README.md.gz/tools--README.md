# Инструменты проекта

Пакет0.0.371 переносит33 performance source,14 tracked UID и4 ignored UID в `tools/qa/performance`; четыре публичных фасада и защищённый sampler остаются: root314→285. Обновлены54 живых Python-потребителя, включая запуск прежних root CLI из чужой cwd/Git. Старые FROZEN-ключи/архивы сохраняются; новый collector читает canonical входы, записывает прежний namespace и явный closed layout `qa-performance-v1`. Восемь новых layout-контролей защищают реальный producer/archive/child argv и mutable SAMPLER; fake-open свидетель не является нативной/FPS-приёмкой. [Профиль переноса371](../docs/reports/refactor-03/performance-move/after-profile.json) сопоставляет настоящие CLI,14 SIGKILL save workers и headless smoke180;18 GD проходят свежий parse. 370 head9a2ad81f принят промежуточным review5690964419/Team; его итоговый CI учитывается отдельно. Для371 обязательны собственные полные gates/CI и независимое ревью точного head.03 остаётся in_progress, финального merge нет. Общий gates-01 выявил frozen import `performance_protocol` до импорта gate; дополнительный четвёртый фасад сохраняет эти исполняемые отчёты. Исходная карта/архивы не переписаны, исключение ожидает независимого ревью. Один source8-case теста воспроизвёл1fail/1error→8/0.


Подготовка0.0.370 performance исправляет8 source-root sites,9 Git-read sites и2 публичных shell-root. Пять настоящих context-тестов проверяют чужие cwd/GIT/index/config: до правки4fail/1error, после требуется5/0 на неизменном test source. Shell smoke в этих тестах использует только fake-engine свидетель argv/cwd. Физических переносов/UID-перемещений нет, root314. Команда: `python3 tools/run.py qa.performance.test_performance_context`. [Профиль подготовки](../docs/reports/refactor-03/performance-prepare/after-profile.json) сравнивает реальные CLI/неизменные данные,14 собственных headless SIGKILL checkpoints и smoke180; старые native FPS-данные лишь перепроверяются offline, новый GPU/FPS-допуск не заявляется. Пакет369 headc6f323d8 принят review5690215352/Team и CI8/8; всей03 это не завершает.

Пакет0.0.369 переносит89 compatibility source и64 tracked UID, сохраняет23 ignored UID: root403→314. Godot-профили теперь в `res://tools/qa/compatibility/`; команды Python — `python3 tools/run.py qa.compatibility.farm_cycles <catalog> <output>` и `python3 tools/run.py qa.compatibility.check_alchemy_reports`. [Сравнение](../docs/reports/refactor-03/compatibility-move/after-profile.json) сохраняет реальные before/after результаты. 368 принят промежуточным source review5689214200/Team и CI8/8. Полная03 остаётся in_progress до root≤30 и финальной приёмки.

Пакет0.0.368 переносит17 alpha/slicing source и2 JSON, сохраняет6 ignored UID; root420→403. Команды: `python3 tools/run.py assets.alpha.alpha_audit`, `python3 tools/run.py assets.slicing.slice_audit`, `python3 tools/run.py assets.alpha.alpha_fixtures /private/tmp/alpha-new-controls`. Нативные скрипты находятся в `res://tools/assets/alpha/` и `res://tools/assets/slicing/`; исходный namespace самостоятельных внешних стендов не переименовывается. [Профиль](../docs/reports/refactor-03/alpha-slicing-move/profile.json) проверяет настоящий exporter/публичный report, пиксели,9 controls, отказ перезаписи и сохранение старых proof. 367 принят промежуточным source review5688074197/Team и CI8/8; это не финальная приёмка03.

Кандидат0.0.365 переносит связанное assets/contracts, assets/migration и build:61 source/8 tracked UID/2 JSON,18 ignored UID; текущий root420. Команды запускаются через `python3 tools/run.py assets.contracts.visual_pipeline`, `python3 tools/run.py assets.migration.asset_migration`, `python3 tools/run.py build.artist_packet`. Godot использует новые `res://tools/assets/contracts/…` и `res://tools/build/…`. Старые логические имена в proofs/manifest сохраняются; current_source выбирает только canonical файл, historical_source — единственный alias из своего commit tree. [Профиль](../docs/reports/refactor-03/assets-build-move/profile-02.json) проверяет старый/новый настоящий экспорт и отрицательные metadata. Пакет364 head6af72 принят review5676273527/Team Lead и CI8/8; вся03 остаётся in_progress до полного root≤30/приёмки.

Подготовка assets/build0.0.364 внутри текущей REFACTOR-03:15 Python source-root,9 изолированных Git-read и отдельная граница старого/свежего scanner. `python3 tools/run.py assets.migration.test_scanner_history` выполняет12 настоящих контролей. Физического переноса ещё нет, текущий root481,03 in_progress; [профиль](../docs/reports/refactor-03/assets-history-prepare/profile.json) и старые inventory не переподписываются. Пакет363 принят промежуточным review5675903250/Team Lead; это не merge всей03.

Пакет art-standard0.0.363 перемещает23 исходника/3 tracked UID в `tools/qa/art` (root481). Команды: `python3 tools/run.py qa.art.visual_scale verify`, `python3 tools/run.py qa.art.visual_modules`, `python3 tools/run.py qa.art.test_current_paths`. Новые capture идут по `res://tools/qa/art/…`; сохранённые VART-доказательства остаются на своих Git/SHA. Логические SOURCES/ORIGINAL не переписываются: свежие scale/pilot collectors записывают известный `source_paths`. [Отчёт](../docs/reports/refactor-03/art-standard-move/README.md) сохраняет точную карту и проверки.

Последняя команда пользователя28.10.2026 отменяет остановку: полная03 →07 →06 → обычный маршрут первой overworld до VMAP-003 по актуальным зависимостям, без дополнительных подтверждений владельца. Текущую03 доводим до полного принятого результата; отдельный пакет не закрывает бюджет≤30.

Подготовка art-standard0.0.362 сохраняет исторические code SHA пяти Godot-исходников через полный main commit и новый `common.history`; текущий файл не заменяет недоступную историю. Восемь прежних Python CLI используют общий source-root, Git-вызовы scale/reuse очищают окружение. Публичные команды пока остаются на прежних местах; при физическом переносе bare common imports квалифицируются вместе с потребителями. `python3 tools/run.py common.test_history` проверяет21 настоящую границу Git/worktree. Root504 не меняется; доказательства — `docs/reports/refactor-03/art-history-prepare/`.

REFACTOR-03 в работе на базе `d609ab4f`. Первый authoring-пакет перемещён в `tools/assets/authoring`:31 исходник и5 tracked UID;9 локальных UID сохраняют ignored-состояние. Первый пакет уменьшил корень544→513; итоговый бюджет≤30 ещё не достигнут. Команда из любой cwd: `python3 /полный/путь/tools/run.py assets.authoring.build_forest_tree_atlas --help`. Связанные генераторы используют общий source-root и прежние аргументы. Генератор без `--help` может записывать ресурсы; проверка импорта не исполняет его main. Карта и проверки этапа находятся в `docs/reports/refactor-03/authoring-move/`.

Четыре офлайн-аудио-инструмента теперь находятся в `tools/assets/audio`: композитор, эффекты, аудит и общий запуск. Поддерживаемая команда: `python3 tools/run.py assets.audio.generate_audio_assets` в среде с NumPy. После аудио-пакета корень tools составил509; функции, WAV и прежний CLI сохранены. Проверки чисел и записывающего audit выполняются только на временных копиях, результаты — в `docs/reports/refactor-03/audio-move/`.

Image/review-пакет0.0.361 переносит PIL importer в `tools/assets/authoring`, а ручную арт-ревизию — в `tools/dev/art_review`. Команды: `python3 tools/run.py dev.art_review.check_art_review`, `python3 tools/run.py dev.art_review.test_art_review`, `node tools/dev/art_review/art_review_serve.mjs`; Godot export: `res://tools/dev/art_review/art_review_export.gd`. Импортёр использует личный Downloads и пишет PNG: main не нужен для проверки переноса. Корень теперь504; карта, сравнение изображений и CLI — `docs/reports/refactor-03/image-review-move/`.

Пилот REFACTOR-02 разделяет `common` (границы запуска), `quality` (проверки репозитория) и `planning` (планы/служебный учёт). Перенесены 14 назначений принятой ведомости. QA/asset/build-переносы остаются REFACTOR-03; движок `tools/Godot.app` сохраняет прежнее место.

Корень определяется по исходнику и маркерам `project.godot`, `VERSION`, `tools`, независимо от cwd, глубины или Git-окружения. `run.py` сохраняет аргументы, вывод, exit и настоящий `__main__` для unittest. Из любой cwd: `python3 /полный/путь/tools/run.py planning.project_backlog`. Из корня также работает `python3 -m tools.run quality.check_documentation`. Текущий каталог не меняется. Выбранный проект имеет приоритет над внешним пакетом tools, даже если корень уже стоял ниже в PYTHONPATH. Внутри процесса временно доступен legacy-корень tools для ещё не перенесённой зависимости pilot_rollout → migration_inventory → visual_pipeline; это снимается вместе с её переносом в REFACTOR-03. Глобальный PYTHONPATH не устанавливается.

Основные команды:

```sh
python3 tools/run.py quality.check_documentation
python3 tools/run.py quality.test_documentation
python3 tools/run.py planning.project_backlog
python3 tools/run.py planning.visual_backlog
python3 tools/run.py planning.pilot_rollout --next
python3 tools/run.py planning.test_task_batch
python3 tools/run.py common.test_infrastructure
```

Генераторы `planning.build_art_backlog` и `planning.build_optimization_matrix` сохраняют прежние входы и форматы; они записывают выходы по явной команде. Их регрессионная проверка создаёт только disposable проекты. Старые пути в замороженных отчётах воспроизводятся по закреплённому Git base/капсуле; живые инструкции используют новые команды.

`__init__.py` в корне tools закрепляет собственный пакет, чтобы внешний пакет с тем же именем не подменил команду. Это один дополнительный package marker к прогнозу девяти корневых исходников аудита: итоговый бюджет остаётся не более 30. Принятая историческая ведомость не переписывается.

Git-команды, адресованные отдельному репозиторию, получают копию окружения без `GIT_*`. Это предотвращает повреждение родительских config/index внутри hooks и disposable проверок. Законный alternate index текущего commit hook для `bump_version --stage` сохраняется; очистка не выполняется глобально в родительском процессе.

Публичные совместимые входы делегируют единственной реализации:

| Вход | Реализация | Причина сохранения |
| --- | --- | --- |
| `tools/check_architecture.sh` | `quality/check_architecture.sh` | Hooks и Actions; прежний exit и исполняемый mode |
| `tools/bump_version.py` | `planning/bump_version.py` | Pre-commit, CLI и import API; законный alternate index |
| `tools/task_batch.py` | `planning/task_batch.py` | Post-commit/status и import API; publish остаётся историческим и не обходит PR |

Эти входы удаляются только отдельным одобренным переходом всех публичных потребителей. Импорт возвращает тот же модуль и mutable globals, а не копию функций. Остальные принятые корневые входы `smoke_test.sh`, `performance_gate.sh`, `performance_gate.py` и защищённые `performance_sampler.gd`/`water_audit.gd` сохраняются для следующего этапа. Полный исторический публичный список находится в `docs/reports/refactor-01/integration-1/snapshot/migration-plan-copy.json`.

Проверка инфраструктуры выполняет 13 сценариев: настоящие disposable Git/worktree, argv/exit, пакетный `-m` и публичные API, подмена пакета, ссылки вне tools, нулевой unittest, чужое Git-окружение, alternate index и вложенный архитектурный лимит. Источники, попытки и границы приёмки хранятся в `docs/reports/refactor-02/`.
