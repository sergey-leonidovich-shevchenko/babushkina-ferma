#!/usr/bin/env python3
"""Collect isolated, source-bound VRENDER-004 native images. No FPS claims."""
if not __package__:
    from common.launch import prepare_imports
    from common.paths import project_root
    prepare_imports(project_root(__file__))

import argparse
import gzip
import hashlib
import json
import shutil
import signal
import subprocess
import uuid
from common.git import git_environment
from pathlib import Path
from tools.qa.performance.perf_contract_collect import ROOT, command, context, jobs, native_pid, sha, write

SOURCES = ['assets/game/basement/workbench_1_east.tres', 'assets/game/basement/workbench_1_south.tres', 'assets/game/basement/workbench_1_west.tres', 'assets/game/basement/workbench_atlas_a.png', 'assets/game/environment/forest_tree_growth_atlas_v1.png', 'docs/reports/visual-overhaul/vbase-003/camera-points.json', 'main.tscn', 'project.godot', 'scripts/game_renderer.gd', 'scripts/presentation/basement_visual_system.gd', 'scripts/presentation/object_draw_command.gd', 'scripts/presentation/object_draw_replay.gd', 'scripts/presentation/village_region_renderer.gd', 'scripts/presentation/village_terrain_canvas.gd', 'scripts/presentation/visual_reference_mode.gd', 'scripts/presentation/world_workbench_visual_system.gd', 'scripts/systems/furniture_facing_system.gd', 'scripts/systems/hero_visual_system.gd', 'scripts/systems/orchard_system.gd', 'scripts/systems/presentation_pose_system.gd', 'scripts/systems/render_system.gd', 'scripts/systems/save_system.gd', 'scripts/systems/tree_occlusion_system.gd', 'scripts/systems/tree_system.gd', 'scripts/systems/village_foreground_renderer.gd', 'scripts/systems/village_prop_renderer.gd', 'scripts/systems/village_terrain_renderer.gd', 'scripts/systems/world_projection_system.gd', 'scripts/world_background.gd', 'tests/suites/axial_road_suite.gd', 'tests/suites/object_draw_command_suite.gd', 'tools/ground_seasons_fixture.gd', 'tools/object_command_canvas.gd', 'tools/object_command_capture.gd', 'tools/object_command_collect.py', 'tools/object_command_review.gd', 'tools/render_order_game.gd', 'tools/visual_camera_points.gd']
OVERLAY = {'project.godot', 'tools/object_command_canvas.gd', 'scripts/presentation/object_draw_command.gd', 'tools/object_command_review.gd', 'tests/suites/object_draw_command_suite.gd', 'tools/object_command_collect.py', 'tools/object_command_capture.gd', 'scripts/presentation/object_draw_replay.gd', 'scripts/presentation/world_workbench_visual_system.gd'}

def collect(folder, static_coexistence=False):
    """Archive exact inputs before opening two fresh native processes, preserving partial failures."""
    if folder.exists(): raise ValueError('unused output required')
    initial_jobs=jobs()
    if initial_jobs and not static_coexistence: raise ValueError('another Godot is active; static-only coexistence must be explicit')
    changed=set(command(['git','diff','HEAD','--name-only','--','scripts','assets/game','main.tscn']).splitlines())
    if not changed <= OVERLAY|{'assets/game/world_sprite_manifest.json'}: raise ValueError('unrelated runtime changes')
    folder.mkdir(parents=True)
    base=command(['git','rev-parse','HEAD']); source={'task':'VRENDER-004','base_commit':base,'base_version':command(['git','show',base+':VERSION']),'complete':False,'static_coexistence':static_coexistence,'initial_jobs':initial_jobs,'performance_eligible':False,'sources':{},'base_sources':{},'artifacts':{}}
    for name in SOURCES:
        target=folder/'inputs'/name; target.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(ROOT/name,target)
        source['sources'][name]=sha(target)
        historical=subprocess.run(['git','show',base+':'+name],cwd=ROOT,capture_output=True, env=git_environment())
        source['base_sources'][name]=hashlib.sha256(historical.stdout).hexdigest() if historical.returncode==0 else None
    write(folder/'source.json',source)
    for width in [1152,1280]:
        if set(jobs())-set(initial_jobs): raise ValueError('another unexpected Godot appeared')
        target=folder/str(width); target.mkdir(); profile='Codex-VRENDER-004-'+uuid.uuid4().hex
        args=['open','-n','-W','-a',str(ROOT/'tools/Godot.app'),'--args','--path',str(ROOT),'--windowed','--resolution',str(width)+'x'+str(round(width*9/16)),'--audio-driver','Dummy',
            '--log-file',str(target/'engine.txt'),'--script','res://tools/object_command_capture.gd','--','--output='+str(target/'native'),'--profile='+profile]
        if width==1280: args.append('--wide')
        before=context(); print('OBJECT COMMAND NATIVE',width,flush=True)
        with (target/'stdout.txt').open('w') as out:
            child=subprocess.Popen(args,cwd=ROOT,stdout=out,stderr=subprocess.STDOUT)
            try: code=child.wait(timeout=180)
            except subprocess.TimeoutExpired:
                pid=native_pid(profile)
                if pid: import os; os.kill(pid,signal.SIGTERM)
                child.terminate(); child.wait(timeout=10); raise ValueError('own capture timed out')
        write(target/'environment.json',{'command':args,'profile':profile,'exit_code':code,'before':before,'after':context(),'existing_jobs_before':initial_jobs,'jobs_after':jobs(),'static_coexistence':static_coexistence})
        if (target/'native').exists():
            for p in (target/'native').iterdir(): shutil.move(str(p),target/p.name)
            (target/'native').rmdir()
        for p in target.glob('*-draws.json'):
            with gzip.GzipFile(str(p)+'.gz','wb',mtime=0) as stream: stream.write(p.read_bytes())
            p.unlink()
        source['artifacts']={str(p.relative_to(folder)):sha(p) for p in folder.rglob('*') if p.is_file() and p.name!='source.json' and 'inputs' not in p.parts}
        write(folder/'source.json',source)
        if not (target/'capture.json').exists(): raise ValueError('native process ended before completion; partial proof preserved and rejected')
        if code or json.loads((target/'capture.json').read_text()).get('errors') or any(token in (target/'engine.txt').read_text() for token in ['ERROR:','SCRIPT ERROR','Parse Error']) or any(sha(ROOT/p)!=s for p,s in source['sources'].items()): raise ValueError('capture failed, engine error or frozen input changed')
    source['complete']=True; write(folder/'source.json',source)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--static-coexistence',action='store_true',help='Frozen visual proof only; record existing Godot without touching it; never performance evidence')
    args=parser.parse_args(); collect(args.output.resolve(),args.static_coexistence)
