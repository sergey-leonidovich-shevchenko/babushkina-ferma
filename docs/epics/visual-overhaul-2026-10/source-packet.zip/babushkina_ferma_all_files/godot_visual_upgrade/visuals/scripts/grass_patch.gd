extends Sprite2D
## Optional setup helper. This shader contract uses an entire, standalone texture.
## Place the node origin at the plant's roots. Keep the Sprite2D local position zero
## if it is a child of a separate GrassPatch root. Do not attach this to a TileMap.
## No per-frame processing is needed here.


func _ready() -> void:
	if texture == null:
		push_error("GrassPatch requires a texture.")
		return
	if texture is AtlasTexture or region_enabled or hframes != 1 or vframes != 1:
		push_error("Grass MVP requires standalone textures, without regions or frames.")
		return
	if flip_v:
		push_error("Grass MVP does not support vertical texture flipping.")
		return
	centered = true
	offset = Vector2(0.0, -float(texture.get_height()) * 0.5)
