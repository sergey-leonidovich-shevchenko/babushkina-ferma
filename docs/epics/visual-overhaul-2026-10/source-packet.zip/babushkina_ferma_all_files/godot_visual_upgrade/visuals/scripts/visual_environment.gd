extends Node
## One active writer per running world; not one script per grass sprite.
## Add config/shader_globals.cfg.example to Project Settings BEFORE loading shaders.
## actor_anchor must be the character's ground/feet anchor in WORLD coordinates.
## This baseline reads logical transforms, not engine-interpolated render positions.

@export var actor_anchor: Node2D
@export var wind_world: Vector2 = Vector2(1.0, 0.12)

const REQUIRED_GLOBALS: Array[StringName] = [
	&"env_time", &"env_actor_position", &"env_actor_active", &"env_wind"
]

var _elapsed: float = 0.0
var _configured: bool = false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	for parameter: StringName in REQUIRED_GLOBALS:
		if not ProjectSettings.has_setting("shader_globals/" + String(parameter)):
			push_error("Missing shader global: %s" % parameter)
			set_process(false)
			return
	_configured = true
	if not is_instance_valid(actor_anchor):
		push_warning("No actor_anchor: wind works, actor interaction is disabled.")
	_publish()


func _process(delta: float) -> void:
	_elapsed += delta
	_publish()


func _publish() -> void:
	RenderingServer.global_shader_parameter_set(&"env_time", _elapsed)
	RenderingServer.global_shader_parameter_set(&"env_wind", wind_world)
	var active: bool = is_instance_valid(actor_anchor) and actor_anchor.is_inside_tree()
	RenderingServer.global_shader_parameter_set(&"env_actor_active", 1.0 if active else 0.0)
	if active:
		RenderingServer.global_shader_parameter_set(
			&"env_actor_position", actor_anchor.global_position
		)


func _exit_tree() -> void:
	if _configured:
		RenderingServer.global_shader_parameter_set(&"env_actor_active", 0.0)
