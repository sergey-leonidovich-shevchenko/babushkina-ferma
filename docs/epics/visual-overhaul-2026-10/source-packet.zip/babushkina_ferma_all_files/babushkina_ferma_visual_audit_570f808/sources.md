# Источники и границы проверки

Снимок: `sergey-leonidovich-shevchenko/babushkina-ferma`, `main`, commit `570f80832d9401059414f960f273051bf958c7c1`, версия приложения из project.godot — `0.0.200`.

Исходники читались через GitHub только на чтение. Указанные ниже файлы/фрагменты прочитаны; ссылки закреплены на commit. Для частично прочитанных файлов выводы ограничены просмотренными функциями и разделами.

Godot не запускался, игра не собиралась, тесты и GPU-профили не выполнялись. Исторические отчёты разработчиков не выдаются за измерения этого аудита.

<a id="s01"></a>

## S01 — `project.godot`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/project.godot). файл целиком.

Версия приложения, Compatibility, canvas_items, конфигурация проекта.

<a id="s02"></a>

## S02 — `main.tscn`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/main.tscn). файл целиком.

Game и WorldBackground; не дерево узлов каждого игрового объекта.

<a id="s03"></a>

## S03 — `scripts/game.gd`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/scripts/game.gd). файл целиком.

Фасад наследует game_core.gd.

<a id="s04"></a>

## S04 — `scripts/game_renderer.gd`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/scripts/game_renderer.gd). выборочно, запрошены строки 1–180.

_draw → RenderSystem; фасады отрисовки.

<a id="s05"></a>

## S05 — `scripts/systems/render_system.gd`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/scripts/systems/render_system.gd). файл целиком.

Фактический порядок мира, героя, переднего плана, атмосферы и UI.

<a id="s06"></a>

## S06 — `scripts/game_context.gd`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/scripts/game_context.gd). выборочно, строки 1–115.

game.player — прокси Vector2 к состоянию, camera_offset, зависимости.

<a id="s07"></a>

## S07 — `scripts/game_core.gd`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/scripts/game_core.gd). выборочно, строки 1–155.

Делегирование цикла, движение и фактическое смещение героя.

<a id="s08"></a>

## S08 — `scripts/core/game_loop.gd`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/scripts/core/game_loop.gd). файл целиком.

Паузы, симуляционный delta, порядок обновления, queue_redraw.

<a id="s09"></a>

## S09 — `scripts/world_background.gd`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/scripts/world_background.gd). выборочно, строки 1–200.

Кеш земли через SubViewport.UPDATE_ONCE, nearest, direct fallback.

<a id="s10"></a>

## S10 — `scripts/systems/village_terrain_renderer.gd`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/scripts/systems/village_terrain_renderer.gd). файл целиком.

Материалы покрытия, capsule-дороги, статичная вода и мост в кеше.

<a id="s11"></a>

## S11 — `scripts/systems/village_ambient_renderer.gd`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/scripts/systems/village_ambient_renderer.gd). файл целиком.

Атлас, фиксированные placements, синусоидальное смещение всего растения.

<a id="s12"></a>

## S12 — `scripts/systems/camera_system.gd`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/scripts/systems/camera_system.gd). файл целиком.

Расчёт camera_offset и округление.

<a id="s13"></a>

## S13 — `scripts/systems/world_visual_profile_system.gd`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/scripts/systems/world_visual_profile_system.gd). файл целиком.

Общие размеры, anchor, collision; деревенский декор 72×72.

<a id="s14"></a>

## S14 — `scripts/systems/tree_occlusion_system.gd`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/scripts/systems/tree_occlusion_system.gd). файл целиком.

Передний/задний проход деревьев, alpha и видимость.

<a id="s15"></a>

## S15 — `scripts/systems/atmosphere_renderer.gd`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/scripts/systems/atmosphere_renderer.gd). файл целиком.

Экранное затемнение, рисованные огни, дождь и снег.

<a id="s16"></a>

## S16 — `scripts/systems/interior_renderer.gd`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/scripts/systems/interior_renderer.gd). выборочно, строки 1–130.

Пол, стены, свет окна и перекрытие мебели.

<a id="s17"></a>

## S17 — `scripts/systems/level_editor_renderer.gd`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/scripts/systems/level_editor_renderer.gd). выборочно, строки 1–105.

Рисование объектов, source, преобразования, переходы покрытий.

<a id="s18"></a>

## S18 — `scripts/systems/published_level_renderer.gd`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/scripts/systems/published_level_renderer.gd). файл целиком.

Опубликованный уровень использует LevelEditorRenderer.draw_object.

<a id="s19"></a>

## S19 — `scripts/systems/water_map_registry.gd`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/scripts/systems/water_map_registry.gd). файл целиком.

Один источник водных планов, отдельные surface/blocks, кеш максимум двух карт.

<a id="s20"></a>

## S20 — `scripts/systems/water_topology.gd`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/scripts/systems/water_topology.gd). выборочно, строки 1–170.

Топология, 24 px, чанки, метаданные, flow, bridges, ревизии.

<a id="s21"></a>

## S21 — `docs/epics/water-2026-10/README.md`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/docs/epics/water-2026-10/README.md). выборочно: начало и запрос строк 100–215; большие ответы обрезались.

Статусы WATER, художественные ограничения, WATER-02…07; не весь файл.

<a id="s22"></a>

## S22 — `docs/reports/water-2026-10/README.md`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/docs/reports/water-2026-10/README.md). файл целиком.

Исторический протокол WATER-01, ограничения и бюджеты.

<a id="s23"></a>

## S23 — `docs/backlog/README.md`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/docs/backlog/README.md). файл целиком.

Общий указатель планов и запрет двух владельцев одной задачи.

<a id="s24"></a>

## S24 — `docs/backlog/2026-10/README.md`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/docs/backlog/2026-10/README.md). выборочно: 1–125, 1260–1405, 1520–1710.

Базовые эпики, OPT-01, WORLD-05, UX-04…08.

<a id="s25"></a>

## S25 — `docs/BACKLOG_WORKFLOW.md`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/docs/BACKLOG_WORKFLOW.md). файл целиком.

Файловый бэклог, одна активная задача, ветки, доказательства.

<a id="s26"></a>

## S26 — `docs/ART_GUIDE.md`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/docs/ART_GUIDE.md). прочитан ответ на запрос строк 1–100.

Пиксельный стандарт, nearest, реестр и профили; ряд исторических разделов.

<a id="s27"></a>

## S27 — `docs/SPRITE_STANDARD.md`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/docs/SPRITE_STANDARD.md). выборочно: начало, запрос 1–135 обрезался.

Три ракурса предметов, сетка, мастер и runtime, правила альфа-края.

<a id="s28"></a>

## S28 — `AGENTS.md`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/AGENTS.md). файл целиком.

Правила проекта; макеты отдельно от runtime, ограничения ракурсов.

<a id="s29"></a>

## S29 — `TESTING.md`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/TESTING.md). выборочно: начало, запрос 1–110 обрезался.

Названные suites и стенды WATER, SAFE, RNG, проверки бэклога.

<a id="s30"></a>

## S30 — `ARCHITECTURE.md`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/ARCHITECTURE.md). выборочно: начало, запрос 1–120.

Состояние/рендер, профили, манифест, отсутствие игровой мутации из draw.

<a id="s31"></a>

## S31 — `scripts/core/game_bootstrap.gd`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/scripts/core/game_bootstrap.gd). выборочно, строки 1–125.

Инициализация и существующие preview входы.

<a id="s32"></a>

## S32 — `scripts/systems/animation_renderer.gd`

[Закреплённый исходник](https://github.com/sergey-leonidovich-shevchenko/babushkina-ferma/blob/570f80832d9401059414f960f273051bf958c7c1/scripts/systems/animation_renderer.gd). выборочно, строки 1–110.

Округление позиции героя перед рисованием, настоящие игровые состояния.

## Официальная документация Godot

- [Custom drawing in 2D](https://docs.godotengine.org/en/4.5/tutorials/2d/custom_drawing_in_2d.html): draw-команды и кеширование.

- [CanvasItem](https://docs.godotengine.org/en/stable/classes/class_canvasitem.html): material, Y-sort, порядок CanvasItem.

- [CanvasItem shaders](https://docs.godotengine.org/en/stable/tutorials/shaders/shader_reference/canvas_item_shader.html): координаты вершин и TIME.

- [SubViewport](https://docs.godotengine.org/en/stable/classes/class_subviewport.html): UPDATE_ONCE.

Раздел stable может обновляться. Документация подтверждает общие механизмы; совместимость реализации нужно проверить на фактическом бинарнике проекта. README указывает 4.7.1, project.godot — feature 4.7; бинарник здесь не проверялся.
